<?php
declare(strict_types=1);
?>

<section class="p-6">
    <div class="bg-white p-6 rounded shadow max-w-xl">
        <h2 class="text-xl font-bold mb-4 text-red-600">
            Verwijder product
        </h2>

        <p class="mb-4">Ben je zeker dat je dit product wilt verwijderen?</p>

        <p class="mb-6">
            <strong><?= htmlspecialchars((string)$product['name'], ENT_QUOTES) ?></strong>
        </p>

        <form method="post" action="<?= ADMIN_BASE_PATH; ?>/products/<?= (int)$product['id']; ?>/delete">
            <input type="hidden" name="_token" value="<?= \Admin\Core\Csrf::token(); ?>">
            /products/<?= (int)$product['id']; ?>/delete">
            <div class="flex gap-4">
                <button class="border px-4 py-2 text-red-600" type="submit">Ja, verwijder</button>
                <a class="underline" href="<?= ADMIN_BASE_PATH; ?>/products">Annuleren</a>
            </div>
        </form>
    </div>
</section>